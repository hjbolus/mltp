# mltp/logic/__init__.py

__version__ = "0.1.0"

from . import predicates
from . import propositions

__all__ = ['predicates', 'propositions']